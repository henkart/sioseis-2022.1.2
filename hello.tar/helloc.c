#include	<stdio.h>
void	helloc_()
{
	printf (" Hello gcc world \n");
}
